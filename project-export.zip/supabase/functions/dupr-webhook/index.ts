import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface DUPRLoginEvent {
  eventType: string;
  data: {
    id: string;
    duprId: string;
    email: string;
    userToken: string;
    refreshToken: string;
    stats?: {
      singles?: number;
      doubles?: number;
    };
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const event: DUPRLoginEvent = await req.json();

    if (event.eventType === "LOGIN") {
      const { data, error } = await supabase
        .from("profiles")
        .update({
          dupr_id: event.data.duprId,
          dupr_rating: event.data.stats?.doubles || event.data.stats?.singles || null,
          dupr_user_token: event.data.userToken,
          dupr_refresh_token: event.data.refreshToken,
          updated_at: new Date().toISOString(),
        })
        .eq("id", event.data.id);

      if (error) {
        console.error("Error updating profile:", error);
        return new Response(
          JSON.stringify({ error: "Failed to update profile" }),
          {
            status: 500,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }

      return new Response(
        JSON.stringify({ success: true, message: "Profile updated" }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(
      JSON.stringify({ message: "Event received" }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error processing webhook:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const DUPR_CLIENT_KEY = "test-ck-0a9d3935-1a00-46be-fbf9-6376d4af637c";
const DUPR_CLIENT_SECRET = "test-cs-8f3a3a1740114165fa16db499b4dc31d";

async function getDuprAccessToken(): Promise<string> {
  const authString = btoa(`${DUPR_CLIENT_KEY}:${DUPR_CLIENT_SECRET}`);

  const response = await fetch("https://uat.mydupr.com/api/auth/v1.0/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Basic ${authString}`,
    },
    body: JSON.stringify({
      clientKey: DUPR_CLIENT_KEY,
      clientSecret: DUPR_CLIENT_SECRET,
    }),
  });

  if (!response.ok) {
    throw new Error("Failed to authenticate with DUPR");
  }

  const data = await response.json();
  return data.result?.accessToken || data.accessToken;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: { user }, error: userError } = await supabase.auth.getUser(
      authHeader.replace("Bearer ", "")
    );

    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { matchId } = await req.json();

    if (!matchId) {
      return new Response(
        JSON.stringify({ error: "Match ID is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: match, error: matchError } = await supabase
      .from("tournament_matches")
      .select(`
        id,
        scheduled_time,
        tournament_id,
        team1_score,
        team2_score,
        status,
        tournament:tournaments (
          id,
          name,
          start_date
        ),
        team1:tournament_teams!tournament_matches_team1_id_fkey (
          id,
          team_name,
          player1:profiles!tournament_teams_player1_user_id_fkey (
            id,
            full_name,
            dupr_id
          ),
          player2:profiles!tournament_teams_player2_user_id_fkey (
            id,
            full_name,
            dupr_id
          )
        ),
        team2:tournament_teams!tournament_matches_team2_id_fkey (
          id,
          team_name,
          player1:profiles!tournament_teams_player1_user_id_fkey (
            id,
            full_name,
            dupr_id
          ),
          player2:profiles!tournament_teams_player2_user_id_fkey (
            id,
            full_name,
            dupr_id
          )
        )
      `)
      .eq("id", matchId)
      .maybeSingle();

    if (matchError || !match) {
      console.error("Match fetch error:", matchError);
      return new Response(
        JSON.stringify({ error: "Match not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    if (match.status !== "completed") {
      return new Response(
        JSON.stringify({ error: "Match must be completed before submitting to DUPR" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    if (!match.team1.player1.dupr_id || !match.team1.player2.dupr_id ||
        !match.team2.player1.dupr_id || !match.team2.player2.dupr_id) {
      return new Response(
        JSON.stringify({ error: "All players must have DUPR IDs linked" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const duprToken = await getDuprAccessToken();

    const duprPayload = {
      eventName: match.tournament.name,
      matchDate: match.scheduled_time || match.tournament.start_date,
      teams: [
        {
          players: [
            {
              duprId: match.team1.player1.dupr_id,
              name: match.team1.player1.full_name,
            },
            {
              duprId: match.team1.player2.dupr_id,
              name: match.team1.player2.full_name,
            },
          ],
        },
        {
          players: [
            {
              duprId: match.team2.player1.dupr_id,
              name: match.team2.player1.full_name,
            },
            {
              duprId: match.team2.player2.dupr_id,
              name: match.team2.player2.full_name,
            },
          ],
        },
      ],
      scores: [
        { winner: match.team1_score > match.team2_score ? 0 : 1, score1: match.team1_score, score2: match.team2_score },
      ],
    };

    console.log("Submitting to DUPR:", JSON.stringify(duprPayload, null, 2));

    const duprResponse = await fetch("https://uat.mydupr.com/api/v1.0/match/result", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${duprToken}`,
      },
      body: JSON.stringify(duprPayload),
    });

    const duprResult = await duprResponse.json();
    console.log("DUPR Response:", JSON.stringify(duprResult, null, 2));

    if (!duprResponse.ok || duprResult.status === "FAILURE") {
      return new Response(
        JSON.stringify({
          success: false,
          error: duprResult.message || "Failed to submit to DUPR",
        }),
        {
          status: duprResponse.status || 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: "Match submitted to DUPR successfully",
        duprResponse: duprResult,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error: any) {
    console.error("Error submitting match to DUPR:", error);

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || "Internal server error",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface DuprAuthRequest {
  clientId: string;
  clientKey: string;
  clientSecret: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { clientId, clientKey, clientSecret }: DuprAuthRequest = await req.json();

    if (!clientId || !clientKey || !clientSecret) {
      return new Response(
        JSON.stringify({ error: 'Missing required credentials' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const authString = btoa(`${clientKey}:${clientSecret}`);

    const duprResponse = await fetch('https://api.dupr.gg/auth/v1.0/oauth2/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${authString}`,
      },
      body: new URLSearchParams({
        grant_type: 'client_credentials',
        client_id: clientId.toString(),
      }),
    });

    const duprResult = await duprResponse.json();

    if (!duprResponse.ok) {
      return new Response(
        JSON.stringify({
          success: false,
          error: duprResult.message || 'Failed to authenticate with DUPR',
        }),
        {
          status: duprResponse.status,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        result: duprResult.result,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Error authenticating with DUPR:', error);

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Internal server error',
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Link from 'next/link';
import Image from 'next/image';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      setError(error.message);
      setLoading(false);
    } else {
      router.push('/dashboard');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-[#374555] to-[#3d4f5f] p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <Image
              src="/dinkheads_logo_final.png"
              alt="DinkHeads"
              width={200}
              height={200}
              className="w-48 h-auto drop-shadow-[0_8px_16px_rgba(0,0,0,0.4)]"
              priority
            />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Welcome back!</h2>
          <p className="text-white/70">Sign in to your account</p>
        </div>

        <div className="dinkheads-card p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="text-sm text-white bg-red-500/20 border border-red-500/50 rounded-2xl p-4">
                {error}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white font-semibold">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={loading}
                className="h-14 dinkheads-input"
                placeholder="you@example.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-white font-semibold">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={loading}
                className="h-14 dinkheads-input"
                placeholder="Enter your password"
              />
            </div>
            <Button
              type="submit"
              className="w-full h-14 text-lg dinkheads-button-primary"
              disabled={loading}
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </Button>
            <p className="text-center text-sm text-white/70 pt-2">
              Need an account?{' '}
              <Link href="/signup" className="text-[#5dd9a8] hover:underline font-semibold">
                Sign up
              </Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { useAuth } from '@/lib/contexts/auth-context';
import { supabase } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';
import { Trophy, User, LogOut, Search } from 'lucide-react';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    router.push('/login');
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-[#374555] to-[#3d4f5f]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#5dd9a8] border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#374555] to-[#3d4f5f]">
      <header className="sticky top-0 z-50 w-full border-b-2 border-white/10 backdrop-blur-lg bg-[#3d4f5f]/80">
        <div className="flex h-16 items-center justify-between px-6 max-w-7xl mx-auto">
          <Link href="/dashboard/tournaments" className="flex items-center">
            <Image
              src="/dinkheads_logo_final.png"
              alt="DinkHeads"
              width={120}
              height={120}
              className="h-12 w-auto"
              priority
            />
          </Link>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              className="text-white hover:bg-white/10"
              onClick={() => router.push('/dashboard/tournaments')}
            >
              <Search className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="pb-20">
        {children}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t-2 border-white/10 backdrop-blur-lg bg-[#3d4f5f]/80">
        <div className="flex items-center justify-around h-20 max-w-7xl mx-auto px-4">
          <Link href="/dashboard/tournaments">
            <Button
              variant="ghost"
              className={`flex flex-col items-center gap-1 h-16 hover:bg-white/10 ${
                pathname?.includes('/tournaments') ? 'text-[#5dd9a8]' : 'text-white/70'
              }`}
            >
              <Trophy className="h-6 w-6" />
              <span className="text-xs">Tournaments</span>
            </Button>
          </Link>
          <Link href="/dashboard/profile">
            <Button
              variant="ghost"
              className={`flex flex-col items-center gap-1 h-16 hover:bg-white/10 ${
                pathname === '/dashboard/profile' ? 'text-[#5dd9a8]' : 'text-white/70'
              }`}
            >
              <User className="h-6 w-6" />
              <span className="text-xs">Profile</span>
            </Button>
          </Link>
          <Button
            variant="ghost"
            className="flex flex-col items-center gap-1 h-16 text-white/70 hover:bg-white/10"
            onClick={handleSignOut}
          >
            <LogOut className="h-6 w-6" />
            <span className="text-xs">Sign Out</span>
          </Button>
        </div>
      </nav>
    </div>
  );
}

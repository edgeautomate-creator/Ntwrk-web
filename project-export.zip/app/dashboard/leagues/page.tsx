'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase/client';
import { useAuth } from '@/lib/contexts/auth-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Plus, Trophy, Calendar, Loader2, Users } from 'lucide-react';

export default function LeaguesPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [leagues, setLeagues] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  const [formData, setFormData] = useState({
    leagueName: '',
    description: '',
    seasonName: '',
    type: 'league',
    startDate: '',
    endDate: '',
    hasPlayoffs: false,
    rounds: 1,
    autoGenerateSchedule: false,
    scoringFormat: '11',
    winByMargin: 2,
    bestOf: '3',
    divisionName: '',
    skillLevel: '',
    maxTeams: 8,
  });

  useEffect(() => {
    loadLeagues();
  }, [user]);

  const loadLeagues = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data: userRole } = await supabase
        .from('user_roles')
        .select('organization_id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!userRole) return;

      const { data, error } = await supabase
        .from('leagues')
        .select(`
          *,
          seasons (
            id,
            name,
            start_date,
            end_date,
            type,
            has_playoffs,
            is_active,
            divisions (
              id,
              name,
              skill_level
            )
          )
        `)
        .eq('organization_id', userRole.organization_id);

      if (error) throw error;

      setLeagues(data || []);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateLeague = async () => {
    setLoading(true);
    try {
      const { data: userRole, error: roleError } = await supabase
        .from('user_roles')
        .select('organization_id')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (roleError) {
        console.error('Role query error:', roleError);
        throw new Error(`Failed to fetch organization: ${roleError.message}`);
      }

      if (!userRole) {
        throw new Error('Organization not found. Please contact support.');
      }

      const { data: league, error: leagueError } = await supabase
        .from('leagues')
        .insert({
          organization_id: userRole.organization_id,
          name: formData.leagueName,
          description: formData.description,
          is_public: true,
        })
        .select()
        .single();

      if (leagueError) throw leagueError;

      const { data: season, error: seasonError } = await supabase
        .from('seasons')
        .insert({
          league_id: league.id,
          organization_id: userRole.organization_id,
          name: formData.seasonName,
          start_date: formData.startDate,
          end_date: formData.endDate || null,
          type: formData.type,
          has_playoffs: formData.hasPlayoffs,
          rounds: formData.rounds,
          auto_generate_schedule: formData.autoGenerateSchedule,
          scoring_format: formData.scoringFormat,
          win_by_margin: formData.winByMargin,
          best_of: parseInt(formData.bestOf),
          is_active: true,
        })
        .select()
        .single();

      if (seasonError) throw seasonError;

      const { error: divisionError } = await supabase
        .from('divisions')
        .insert({
          season_id: season.id,
          organization_id: userRole.organization_id,
          name: formData.divisionName,
          skill_level: formData.skillLevel,
          max_teams: formData.maxTeams,
        });

      if (divisionError) throw divisionError;

      toast({
        title: 'Success',
        description: `${formData.type === 'league' ? 'League' : 'Tournament'} created successfully`,
      });

      setDialogOpen(false);
      setFormData({
        leagueName: '',
        description: '',
        seasonName: '',
        type: 'league',
        startDate: '',
        endDate: '',
        hasPlayoffs: false,
        rounds: 1,
        autoGenerateSchedule: false,
        scoringFormat: '11',
        winByMargin: 2,
        bestOf: '3',
        divisionName: '',
        skillLevel: '',
        maxTeams: 8,
      });

      await loadLeagues();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Leagues & Tournaments</h1>
          <p className="text-muted-foreground">Create and manage your pickleball competitions</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create New
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create League or Tournament</DialogTitle>
              <DialogDescription>
                Set up a new pickleball competition with customizable options
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              <div className="space-y-4">
                <div className="pb-3 border-b">
                  <h3 className="font-semibold text-lg">Basic Information</h3>
                  <p className="text-sm text-muted-foreground">Set up your competition details</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Competition Type</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value) => setFormData({ ...formData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="league">League (Round Robin)</SelectItem>
                      <SelectItem value="tournament">Tournament (Bracket)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="leagueName">
                    {formData.type === 'league' ? 'League' : 'Tournament'} Name
                  </Label>
                  <Input
                    id="leagueName"
                    value={formData.leagueName}
                    onChange={(e) => setFormData({ ...formData, leagueName: e.target.value })}
                    placeholder="e.g., Summer Pickleball League"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe your competition..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="seasonName">Season Name</Label>
                  <Input
                    id="seasonName"
                    value={formData.seasonName}
                    onChange={(e) => setFormData({ ...formData, seasonName: e.target.value })}
                    placeholder="e.g., Summer 2024"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={formData.startDate}
                      onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate">End Date (Optional)</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={formData.endDate}
                      onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    />
                  </div>
                </div>

                <div className="pb-3 border-b mt-6">
                  <h3 className="font-semibold text-lg">Division Setup</h3>
                  <p className="text-sm text-muted-foreground">Configure player divisions and skill levels</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="divisionName">Division Name</Label>
                  <Input
                    id="divisionName"
                    value={formData.divisionName}
                    onChange={(e) => setFormData({ ...formData, divisionName: e.target.value })}
                    placeholder="e.g., Mixed Doubles"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="skillLevel">Skill Level</Label>
                    <Input
                      id="skillLevel"
                      value={formData.skillLevel}
                      onChange={(e) => setFormData({ ...formData, skillLevel: e.target.value })}
                      placeholder="e.g., 3.5-4.0"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maxTeams">Max Teams</Label>
                    <Input
                      id="maxTeams"
                      type="number"
                      min="2"
                      value={formData.maxTeams}
                      onChange={(e) => setFormData({ ...formData, maxTeams: parseInt(e.target.value) || 8 })}
                    />
                  </div>
                </div>

                <div className="pb-3 border-b mt-6">
                  <h3 className="font-semibold text-lg">Game Rules</h3>
                  <p className="text-sm text-muted-foreground">Define scoring and match format</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="scoringFormat">Scoring Format</Label>
                  <Select
                    value={formData.scoringFormat}
                    onValueChange={(value) => setFormData({ ...formData, scoringFormat: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="11">Play to 11</SelectItem>
                      <SelectItem value="15">Play to 15</SelectItem>
                      <SelectItem value="21">Play to 21</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="winByMargin">Win by Margin</Label>
                    <Input
                      id="winByMargin"
                      type="number"
                      min="1"
                      value={formData.winByMargin}
                      onChange={(e) => setFormData({ ...formData, winByMargin: parseInt(e.target.value) || 2 })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bestOf">Match Format</Label>
                    <Select
                      value={formData.bestOf}
                      onValueChange={(value) => setFormData({ ...formData, bestOf: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Best of 1</SelectItem>
                        <SelectItem value="3">Best of 3</SelectItem>
                        <SelectItem value="5">Best of 5</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="pb-3 border-b mt-6">
                  <h3 className="font-semibold text-lg">Additional Options</h3>
                  <p className="text-sm text-muted-foreground">Configure playoffs and scheduling</p>
                </div>

                {formData.type === 'tournament' && (
                  <div className="space-y-2">
                    <Label htmlFor="rounds">Number of Rounds</Label>
                    <Input
                      id="rounds"
                      type="number"
                      min="1"
                      value={formData.rounds}
                      onChange={(e) => setFormData({ ...formData, rounds: parseInt(e.target.value) || 1 })}
                    />
                  </div>
                )}

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-0.5">
                    <Label>Playoffs</Label>
                    <p className="text-sm text-muted-foreground">
                      Enable playoff rounds after regular season
                    </p>
                  </div>
                  <Switch
                    checked={formData.hasPlayoffs}
                    onCheckedChange={(checked) => setFormData({ ...formData, hasPlayoffs: checked })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-0.5">
                    <Label>Auto-Generate Schedule</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically create match schedule
                    </p>
                  </div>
                  <Switch
                    checked={formData.autoGenerateSchedule}
                    onCheckedChange={(checked) => setFormData({ ...formData, autoGenerateSchedule: checked })}
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setDialogOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleCreateLeague} disabled={loading} className="flex-1">
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Create {formData.type === 'league' ? 'League' : 'Tournament'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {loading && leagues.length === 0 ? (
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      ) : leagues.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Trophy className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-lg font-semibold mb-2">No leagues or tournaments yet</p>
            <p className="text-muted-foreground mb-4">
              Create your first competition to get started
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {leagues.map((league) => (
            <Card key={league.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <Trophy className="h-5 w-5" />
                    {league.name}
                  </CardTitle>
                </div>
                <CardDescription>{league.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {league.seasons && league.seasons.length > 0 && (
                  <div className="space-y-3">
                    {league.seasons.map((season: any) => (
                      <div key={season.id} className="p-4 border rounded-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="font-semibold flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            {season.name}
                          </p>
                          <div className="flex items-center gap-2">
                            {season.type === 'tournament' && (
                              <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                                Tournament
                              </span>
                            )}
                            {season.has_playoffs && (
                              <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                                Playoffs
                              </span>
                            )}
                            {season.is_active && (
                              <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-1 rounded">
                                Active
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <p>
                            {new Date(season.start_date).toLocaleDateString()} -{' '}
                            {season.end_date ? new Date(season.end_date).toLocaleDateString() : 'Ongoing'}
                          </p>
                          <p>
                            Scoring: Play to {season.scoring_format}, Win by {season.win_by_margin}
                            {season.best_of && ` • Best of ${season.best_of}`}
                          </p>
                        </div>
                        {season.divisions && season.divisions.length > 0 && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Users className="h-4 w-4" />
                            {season.divisions.length} Division{season.divisions.length !== 1 ? 's' : ''}
                            {season.divisions.map((div: any) => (
                              <span key={div.id} className="text-xs bg-slate-100 px-2 py-1 rounded">
                                {div.name} {div.skill_level && `(${div.skill_level})`}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Loader2, CheckCircle2, Link as LinkIcon, Unlink, Search, AlertCircle, LogIn } from 'lucide-react';
import { useAuth } from '@/lib/contexts/auth-context';
import { DUPRLoginModal } from '@/components/dupr-login-modal';

export default function ProfilePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [duprConnected, setDuprConnected] = useState(false);
  const [profileData, setProfileData] = useState<any>(null);
  const [showDuprLogin, setShowDuprLogin] = useState(false);

  useEffect(() => {
    loadProfileData();
  }, [user]);

  const loadProfileData = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();

    if (data) {
      setProfileData(data);
      setDuprConnected(!!data.dupr_id);
    }
  };

  const handleDisconnectDupr = async () => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          dupr_id: null,
          dupr_singles_rating: null,
          dupr_doubles_rating: null,
          dupr_singles_wins: null,
          dupr_singles_losses: null,
          dupr_doubles_wins: null,
          dupr_doubles_losses: null,
          dupr_data: null,
          full_name: null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user?.id);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'DUPR account disconnected',
      });

      setDuprConnected(false);
      await loadProfileData();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Profile</h1>
        <p className="text-muted-foreground">Connect your DUPR account to participate in tournaments</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {duprConnected ? (
              <>
                <CheckCircle2 className="h-5 w-5 text-green-500" />
                DUPR Profile Linked
              </>
            ) : (
              <>
                <LinkIcon className="h-5 w-5" />
                Connect Your DUPR Account
              </>
            )}
          </CardTitle>
          <CardDescription>
            {duprConnected
              ? 'Your DUPR account is linked. You can participate in DUPR-required tournaments.'
              : 'Sign in with your DUPR account to link your profile and access your ratings.'
            }
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {duprConnected && profileData ? (
            <div className="p-4 border rounded-lg bg-muted/30">
              <div className="font-medium">{profileData.full_name || 'DUPR User'}</div>
              <div className="text-sm text-muted-foreground mt-2 space-y-1">
                <div>DUPR ID: {profileData.dupr_id}</div>
                {profileData.dupr_singles_rating && (
                  <div>Singles: {profileData.dupr_singles_rating} ({profileData.dupr_singles_wins || 0}W - {profileData.dupr_singles_losses || 0}L)</div>
                )}
                {profileData.dupr_doubles_rating && (
                  <div>Doubles: {profileData.dupr_doubles_rating} ({profileData.dupr_doubles_wins || 0}W - {profileData.dupr_doubles_losses || 0}L)</div>
                )}
              </div>
            </div>
          ) : null}

          {duprConnected ? (
            <Button
              onClick={handleDisconnectDupr}
              disabled={loading}
              variant="destructive"
              className="w-full"
            >
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              <Unlink className="mr-2 h-4 w-4" />
              Disconnect DUPR
            </Button>
          ) : (
            <Button
              onClick={() => setShowDuprLogin(true)}
              className="w-full"
            >
              <LogIn className="mr-2 h-4 w-4" />
              Login with DUPR
            </Button>
          )}
        </CardContent>
      </Card>

      <DUPRLoginModal
        open={showDuprLogin}
        onOpenChange={setShowDuprLogin}
        onSuccess={() => {
          toast({
            title: 'Success',
            description: 'DUPR account linked successfully',
          });
          loadProfileData();
        }}
      />
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Calendar, MapPin, Users, Trophy, Copy, Check, AlertCircle, UserPlus, Edit2 } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface Tournament {
  id: string;
  name: string;
  date: string | null;
  start_time: string | null;
  location: string | null;
  expected_teams: number;
  playoff_teams: number;
  format: string;
  best_of: number;
  is_private: boolean;
  access_code: string | null;
  share_token: string;
  created_by: string;
  created_at: string;
  is_dupr_required: boolean;
  playoffs_started: boolean;
  playoffs_started_at: string | null;
  champion_team_id: string | null;
}

interface TournamentTeam {
  id: string;
  tournament_id: string;
  team_number: number;
  team_name: string | null;
  player1_name: string | null;
  player1_dupr_id: string | null;
  player1_rating: number | null;
  player1_user_id: string | null;
  player2_name: string | null;
  player2_dupr_id: string | null;
  player2_rating: number | null;
  player2_user_id: string | null;
  claimed_by_user_id: string | null;
  created_at: string;
  updated_at: string;
}

interface TournamentMatch {
  id: string;
  tournament_id: string;
  match_number: number;
  round: string;
  team1_id: string;
  team2_id: string;
  team1_score: number | null;
  team2_score: number | null;
  winner_team_id: string | null;
  status: 'scheduled' | 'in_progress' | 'completed';
  scheduled_time: string | null;
  completed_at: string | null;
  is_playoff_match: boolean;
  playoff_round: string | null;
  bracket_position: number | null;
  team1?: TournamentTeam;
  team2?: TournamentTeam;
}

interface TeamStanding {
  id: string;
  tournament_id: string;
  team_id: string;
  matches_played: number;
  wins: number;
  losses: number;
  points_for: number;
  points_against: number;
  point_differential: number;
  team?: TournamentTeam;
}


export default function TournamentDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [teams, setTeams] = useState<TournamentTeam[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreator, setIsCreator] = useState(false);
  const [copied, setCopied] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState<TournamentTeam | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<'player1' | 'player2' | null>(null);
  const [showClaimDialog, setShowClaimDialog] = useState(false);
  const [claimName, setClaimName] = useState('');
  const [claimError, setClaimError] = useState('');
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [matches, setMatches] = useState<TournamentMatch[]>([]);
  const [standings, setStandings] = useState<TeamStanding[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<TournamentMatch | null>(null);
  const [showScoreDialog, setShowScoreDialog] = useState(false);
  const [team1Score, setTeam1Score] = useState('');
  const [team2Score, setTeam2Score] = useState('');
  const [generatingSchedule, setGeneratingSchedule] = useState(false);
  const [editingTeamName, setEditingTeamName] = useState<string | null>(null);
  const [editedTeamName, setEditedTeamName] = useState('');
  const [activeTab, setActiveTab] = useState('teams');
  const [startingPlayoffs, setStartingPlayoffs] = useState(false);
  const [playoffMatches, setPlayoffMatches] = useState<TournamentMatch[]>([]);

  useEffect(() => {
    loadTournamentData();
  }, [params.id]);


  const loadTournamentData = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      setCurrentUserId(user.id);

      const { data: tournamentData, error: tournamentError } = await supabase
        .from('tournaments')
        .select('*')
        .eq('id', params.id)
        .single();

      if (tournamentError) throw tournamentError;

      setTournament(tournamentData);
      setIsCreator(tournamentData.created_by === user.id);

      const { data: teamsData } = await supabase
        .from('tournament_teams')
        .select('*')
        .eq('tournament_id', params.id)
        .order('team_number', { ascending: true });

      setTeams(teamsData || []);

      await loadMatches();
      await loadStandings();
    } catch (error) {
      console.error('Error loading tournament:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadMatches = async () => {
    const { data: matchesData } = await supabase
      .from('tournament_matches')
      .select('*, team1:tournament_teams!team1_id(*), team2:tournament_teams!team2_id(*)')
      .eq('tournament_id', params.id)
      .eq('is_playoff_match', false)
      .order('match_number', { ascending: true });

    if (matchesData) {
      setMatches(matchesData as any);
    }

    const { data: playoffData } = await supabase
      .from('tournament_matches')
      .select('*, team1:tournament_teams!team1_id(*), team2:tournament_teams!team2_id(*)')
      .eq('tournament_id', params.id)
      .eq('is_playoff_match', true)
      .order('bracket_position', { ascending: true });

    if (playoffData) {
      setPlayoffMatches(playoffData as any);
    }
  };

  const loadStandings = async () => {
    const { data: standingsData } = await supabase
      .from('team_standings')
      .select('*, team:tournament_teams(*)')
      .eq('tournament_id', params.id)
      .order('wins', { ascending: false })
      .order('point_differential', { ascending: false });

    if (standingsData) {
      setStandings(standingsData as any);
    }
  };

  const updateTeamName = async (teamId: string, newName: string) => {
    try {
      const { error } = await supabase
        .from('tournament_teams')
        .update({ team_name: newName, updated_at: new Date().toISOString() })
        .eq('id', teamId);

      if (error) throw error;

      setEditingTeamName(null);
      setEditedTeamName('');
      await loadTournamentData();
    } catch (error) {
      console.error('Error updating team name:', error);
      alert('Failed to update team name');
    }
  };

  const generateSchedule = async () => {
    if (!tournament) return;

    try {
      setGeneratingSchedule(true);

      const filledTeams = teams.filter(t => t.player1_name && t.player2_name);

      if (filledTeams.length < 2) {
        alert('Need at least 2 complete teams to generate a schedule');
        return;
      }

      const matchesToCreate: any[] = [];
      let matchNumber = 1;
      const numTeams = filledTeams.length;
      const matchesPerRound = Math.floor(numTeams / 2);
      const totalRounds = numTeams % 2 === 0 ? numTeams - 1 : numTeams;

      const teamIndices = filledTeams.map((_, i) => i);

      for (let round = 0; round < totalRounds; round++) {
        for (let match = 0; match < matchesPerRound; match++) {
          const home = (round + match) % numTeams;
          const away = (numTeams - 1 - match + round) % numTeams;

          if (home !== away) {
            matchesToCreate.push({
              tournament_id: tournament.id,
              match_number: matchNumber++,
              round: `Round ${round + 1}`,
              team1_id: filledTeams[home].id,
              team2_id: filledTeams[away].id,
              status: 'scheduled',
            });
          }
        }
      }

      const { error } = await supabase
        .from('tournament_matches')
        .insert(matchesToCreate);

      if (error) throw error;

      await loadMatches();
      setActiveTab('schedule');
    } catch (error) {
      console.error('Error generating schedule:', error);
      alert('Failed to generate schedule');
    } finally {
      setGeneratingSchedule(false);
    }
  };

  const openScoreDialog = (match: TournamentMatch) => {
    setSelectedMatch(match);
    setTeam1Score(match.team1_score?.toString() || '');
    setTeam2Score(match.team2_score?.toString() || '');
    setShowScoreDialog(true);
  };

  const submitScore = async () => {
    if (!selectedMatch) return;

    const score1 = parseInt(team1Score);
    const score2 = parseInt(team2Score);

    if (isNaN(score1) || isNaN(score2) || score1 < 0 || score2 < 0) {
      alert('Please enter valid scores');
      return;
    }

    try {
      const winnerId = score1 > score2 ? selectedMatch.team1_id : score2 > score1 ? selectedMatch.team2_id : null;

      const { error } = await supabase
        .from('tournament_matches')
        .update({
          team1_score: score1,
          team2_score: score2,
          winner_team_id: winnerId,
          status: 'completed',
          completed_at: new Date().toISOString(),
        })
        .eq('id', selectedMatch.id);

      if (error) throw error;

      if (selectedMatch.is_playoff_match && selectedMatch.playoff_round === 'Finals' && winnerId) {
        await supabase
          .from('tournaments')
          .update({ champion_team_id: winnerId })
          .eq('id', tournament?.id);
      }

      setShowScoreDialog(false);
      await loadMatches();
      await loadStandings();
      await loadTournamentData();
    } catch (error) {
      console.error('Error submitting score:', error);
      alert('Failed to submit score');
    }
  };

  const startPlayoffs = async () => {
    if (!tournament) return;

    try {
      setStartingPlayoffs(true);

      const topTeams = standings
        .sort((a, b) => {
          if (b.wins !== a.wins) return b.wins - a.wins;
          return b.point_differential - a.point_differential;
        })
        .slice(0, tournament.playoff_teams);

      if (topTeams.length < 2) {
        alert('Need at least 2 teams with completed matches to start playoffs');
        return;
      }

      await supabase
        .from('tournaments')
        .update({
          playoffs_started: true,
          playoffs_started_at: new Date().toISOString(),
        })
        .eq('id', tournament.id);

      const playoffMatchesToCreate: any[] = [];
      let bracketPosition = 1;

      const rounds: Record<number, string> = {
        2: 'Finals',
        4: 'Semifinals',
        8: 'Quarterfinals',
      };

      const nextPowerOf2 = Math.pow(2, Math.ceil(Math.log2(topTeams.length)));
      const roundName = rounds[nextPowerOf2] || `Round of ${nextPowerOf2}`;

      for (let i = 0; i < topTeams.length; i += 2) {
        if (i + 1 < topTeams.length) {
          playoffMatchesToCreate.push({
            tournament_id: tournament.id,
            match_number: 1000 + bracketPosition,
            round: roundName,
            team1_id: topTeams[i].team_id,
            team2_id: topTeams[i + 1].team_id,
            status: 'scheduled',
            is_playoff_match: true,
            playoff_round: roundName,
            bracket_position: bracketPosition,
          });
          bracketPosition++;
        }
      }

      const { error } = await supabase
        .from('tournament_matches')
        .insert(playoffMatchesToCreate);

      if (error) throw error;

      await loadMatches();
      await loadTournamentData();
      setActiveTab('playoffs');
    } catch (error) {
      console.error('Error starting playoffs:', error);
      alert('Failed to start playoffs');
    } finally {
      setStartingPlayoffs(false);
    }
  };


  const initiateClaimTeam = async (team: TournamentTeam, playerSlot: 'player1' | 'player2') => {
    try {
      setClaimError('');
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from('profiles')
        .select('dupr_id, dupr_rating, full_name')
        .eq('id', user.id)
        .maybeSingle();

      if (tournament?.is_dupr_required && !profile?.dupr_id) {
        setClaimError('This tournament requires a DUPR account. Please add your DUPR ID to your profile first.');
        return;
      }

      setSelectedTeam(team);
      setSelectedSlot(playerSlot);

      if (tournament?.is_dupr_required) {
        await confirmClaimTeam(profile?.full_name || user.email?.split('@')[0] || 'Anonymous Player', profile?.dupr_id || null, profile?.dupr_rating || null);
      } else {
        const defaultName = profile?.full_name || user.email?.split('@')[0] || '';
        setClaimName(defaultName);
        setShowClaimDialog(true);
      }
    } catch (error: any) {
      setClaimError(error.message);
    }
  };

  const confirmClaimTeam = async (playerName: string, duprId: string | null = null, rating: number | null = null) => {
    try {
      if (!selectedTeam || !selectedSlot) return;

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const updateData: any = {
        updated_at: new Date().toISOString(),
      };

      if (selectedSlot === 'player1') {
        updateData.player1_name = playerName;
        updateData.player1_dupr_id = duprId;
        updateData.player1_rating = rating;
        updateData.player1_user_id = user.id;
        if (!selectedTeam.claimed_by_user_id) {
          updateData.claimed_by_user_id = user.id;
        }
      } else {
        updateData.player2_name = playerName;
        updateData.player2_dupr_id = duprId;
        updateData.player2_rating = rating;
        updateData.player2_user_id = user.id;
      }

      const { error } = await supabase
        .from('tournament_teams')
        .update(updateData)
        .eq('id', selectedTeam.id);

      if (error) throw error;

      setShowClaimDialog(false);
      setSelectedTeam(null);
      setSelectedSlot(null);
      setClaimName('');
      await loadTournamentData();
    } catch (error: any) {
      setClaimError(error.message);
    }
  };

  const copyShareLink = () => {
    const link = `${window.location.origin}/dashboard/tournaments/${params.id}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const copyAccessCode = () => {
    if (tournament?.access_code) {
      navigator.clipboard.writeText(tournament.access_code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (loading) {
    return (
      <div className="container py-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/3" />
          <div className="h-24 bg-muted rounded" />
          <div className="h-64 bg-muted rounded" />
        </div>
      </div>
    );
  }

  if (!tournament) {
    return (
      <div className="container py-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Tournament not found</AlertDescription>
        </Alert>
      </div>
    );
  }

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return 'Date TBD';
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatTime = (timeStr: string | null) => {
    if (!timeStr) return '';
    return new Date(`2000-01-01T${timeStr}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const filledTeams = teams.filter(t => t.player1_name && t.player2_name);

  return (
    <div className="container py-8">
      <div className="mb-8">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold">{tournament.name}</h1>
              {tournament.is_private && <Badge variant="secondary">Private</Badge>}
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline">
                {tournament.format === 'round_robin' ? 'Round Robin' : 'Group Stage + Playoffs'}
              </Badge>
              <Badge variant="outline">{tournament.playoff_teams} playoff spots</Badge>
            </div>
          </div>
        </div>

        <Card>
          <CardContent className="pt-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div className="text-sm">
                  <div className="font-medium">{formatDate(tournament.date)}</div>
                  {tournament.start_time && (
                    <div className="text-muted-foreground">{formatTime(tournament.start_time)}</div>
                  )}
                </div>
              </div>
              {tournament.location && (
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <div className="text-sm">
                    <div className="font-medium">Location</div>
                    <div className="text-muted-foreground">{tournament.location}</div>
                  </div>
                </div>
              )}
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-muted-foreground" />
                <div className="text-sm">
                  <div className="font-medium">Teams</div>
                  <div className="text-muted-foreground">
                    {filledTeams.length} / {tournament.expected_teams}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Trophy className="h-4 w-4 text-muted-foreground" />
                <div className="text-sm">
                  <div className="font-medium">Playoff Teams</div>
                  <div className="text-muted-foreground">{tournament.playoff_teams}</div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t space-y-3">
              <div className="flex items-center justify-between">
                <Label>Share Tournament Link</Label>
                <Button variant="outline" size="sm" onClick={copyShareLink}>
                  {copied ? (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy Link
                    </>
                  )}
                </Button>
              </div>
              {isCreator && tournament.is_private && tournament.access_code && (
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Access Code</Label>
                    <p className="text-sm font-mono">{tournament.access_code}</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={copyAccessCode}>
                    {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
              )}
            </div>

            {tournament.is_dupr_required && (
              <Alert className="mt-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  This tournament requires a DUPR account to participate.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className={`grid w-full ${tournament.playoffs_started ? 'grid-cols-4' : 'grid-cols-3'}`}>
          <TabsTrigger value="teams">Teams</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="standings">Standings</TabsTrigger>
          {tournament.playoffs_started && (
            <TabsTrigger value="playoffs">
              <Trophy className="h-4 w-4 mr-1" />
              Playoffs
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="teams" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Tournament Teams</CardTitle>
              <CardDescription>
                {filledTeams.length} of {tournament.expected_teams} teams fully registered
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                {teams.map((team) => (
                  <Card key={team.id} className={team.player1_name || team.player2_name ? 'bg-muted/30' : ''}>
                    <CardContent className="pt-6">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          {editingTeamName === team.id ? (
                            <div className="flex items-center gap-2 flex-1">
                              <Input
                                value={editedTeamName}
                                onChange={(e) => setEditedTeamName(e.target.value)}
                                placeholder={`Team ${team.team_number}`}
                                className="max-w-xs"
                                autoFocus
                              />
                              <Button
                                size="sm"
                                onClick={() => updateTeamName(team.id, editedTeamName)}
                                disabled={!editedTeamName.trim()}
                              >
                                Save
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingTeamName(null);
                                  setEditedTeamName('');
                                }}
                              >
                                Cancel
                              </Button>
                            </div>
                          ) : (
                            <>
                              <div className="font-semibold">
                                {team.team_name || `Team ${team.team_number}`}
                              </div>
                              {isCreator && matches.length === 0 && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => {
                                    setEditingTeamName(team.id);
                                    setEditedTeamName(team.team_name || '');
                                  }}
                                >
                                  <Edit2 className="h-4 w-4" />
                                </Button>
                              )}
                            </>
                          )}
                        </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between border rounded-lg p-3">
                        <div className="flex-1">
                          <div className="text-xs text-muted-foreground mb-1">Player 1</div>
                          {team.player1_name ? (
                            <div className="space-y-1">
                              <div className="flex items-baseline gap-2">
                                <span className="text-sm font-medium">{team.player1_name}</span>
                                {team.player1_rating && (
                                  <Badge variant="outline" className="text-xs">
                                    {team.player1_rating} DUPR
                                  </Badge>
                                )}
                              </div>
                              {team.player1_dupr_id && (
                                <div className="text-xs text-muted-foreground">
                                  DUPR ID: {team.player1_dupr_id}
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="text-sm text-muted-foreground">Open Spot</div>
                          )}
                        </div>
                        {!team.player1_name && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setClaimError('');
                              initiateClaimTeam(team, 'player1');
                            }}
                          >
                            <UserPlus className="h-4 w-4 mr-2" />
                            Claim
                          </Button>
                        )}
                      </div>

                      <div className="flex items-center justify-between border rounded-lg p-3">
                        <div className="flex-1">
                          <div className="text-xs text-muted-foreground mb-1">Player 2</div>
                          {team.player2_name ? (
                            <div className="space-y-1">
                              <div className="flex items-baseline gap-2">
                                <span className="text-sm font-medium">{team.player2_name}</span>
                                {team.player2_rating && (
                                  <Badge variant="outline" className="text-xs">
                                    {team.player2_rating} DUPR
                                  </Badge>
                                )}
                              </div>
                              {team.player2_dupr_id && (
                                <div className="text-xs text-muted-foreground">
                                  DUPR ID: {team.player2_dupr_id}
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="text-sm text-muted-foreground">Open Spot</div>
                          )}
                        </div>
                        {!team.player2_name && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setClaimError('');
                              initiateClaimTeam(team, 'player2');
                            }}
                          >
                            <UserPlus className="h-4 w-4 mr-2" />
                            Claim
                          </Button>
                        )}
                      </div>
                    </div>

                    {team.claimed_by_user_id === currentUserId && (
                      <Badge variant="outline" className="text-green-600">
                        Your Team
                      </Badge>
                    )}
                  </div>

                  {claimError && selectedTeam?.id === team.id && (
                    <Alert variant="destructive" className="mt-3">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{claimError}</AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {filledTeams.length >= 2 && matches.length === 0 && isCreator && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Generate Schedule</CardTitle>
            <CardDescription>
              All teams are registered. Create matches for the tournament.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={generateSchedule}
              disabled={generatingSchedule}
              className="w-full"
            >
              {generatingSchedule ? 'Generating...' : 'Create Tournament Schedule'}
            </Button>
          </CardContent>
        </Card>
      )}
    </TabsContent>

    <TabsContent value="schedule" className="mt-6">
      <div className="space-y-6">
        {matches.length > 0 ? (
          <Card>
            <CardHeader>
              <CardTitle>Match Schedule</CardTitle>
              <CardDescription>Click on a match to enter scores</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {(() => {
                  const matchesByRound = matches.reduce((acc, match) => {
                    const round = match.round || 'Unassigned';
                    if (!acc[round]) acc[round] = [];
                    acc[round].push(match);
                    return acc;
                  }, {} as Record<string, TournamentMatch[]>);

                  const sortedRounds = Object.keys(matchesByRound).sort((a, b) => {
                    const numA = parseInt(a.replace(/\D/g, '')) || 0;
                    const numB = parseInt(b.replace(/\D/g, '')) || 0;
                    return numA - numB;
                  });

                  return sortedRounds.map(round => (
                    <div key={round}>
                      <h3 className="font-semibold text-lg mb-3">{round}</h3>
                      <div className="space-y-2">
                        {matchesByRound[round].map((match) => (
                          <div
                            key={match.id}
                            className="bg-card border rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                            onClick={() => openScoreDialog(match)}
                          >
                            <div className="p-4">
                              <div className="flex items-center gap-4">
                                <div className="flex-1 space-y-3">
                                  <div className="text-base font-medium text-foreground">
                                    {match.team1?.player1_name} / {match.team1?.player2_name}
                                  </div>
                                  <div className="flex items-center justify-center">
                                    <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                                      <span className="text-white font-bold text-xs">VS</span>
                                    </div>
                                  </div>
                                  <div className="text-base font-medium text-foreground">
                                    {match.team2?.player1_name} / {match.team2?.player2_name}
                                  </div>
                                </div>
                                <div className="flex flex-col gap-3">
                                  {match.status === 'completed' ? (
                                    <>
                                      <div className="w-16 h-10 border-2 border-border rounded flex items-center justify-center bg-background">
                                        <span className="text-xl font-bold">{match.team1_score}</span>
                                      </div>
                                      <div className="w-16 h-10 border-2 border-border rounded flex items-center justify-center bg-background">
                                        <span className="text-xl font-bold">{match.team2_score}</span>
                                      </div>
                                    </>
                                  ) : (
                                    <>
                                      <div className="w-16 h-10 border-2 border-muted rounded flex items-center justify-center bg-muted/30">
                                        <span className="text-lg text-muted-foreground">-</span>
                                      </div>
                                      <div className="w-16 h-10 border-2 border-muted rounded flex items-center justify-center bg-muted/30">
                                        <span className="text-lg text-muted-foreground">-</span>
                                      </div>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ));
                })()}
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              No schedule generated yet. Generate a schedule from the Teams tab.
            </CardContent>
          </Card>
        )}

        {!tournament.playoffs_started && matches.length > 0 && standings.length >= 2 && isCreator && (
          <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-secondary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-primary" />
                Start Playoffs
              </CardTitle>
              <CardDescription>
                End the regular season and advance the top {tournament.playoff_teams} teams to playoffs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={startPlayoffs}
                disabled={startingPlayoffs}
                className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90"
                size="lg"
              >
                {startingPlayoffs ? 'Starting Playoffs...' : 'Start Playoffs'}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </TabsContent>

    <TabsContent value="standings" className="mt-6">
      {matches.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>Standings</CardTitle>
            <CardDescription>Current tournament rankings</CardDescription>
          </CardHeader>
          <CardContent>
            {standings.length > 0 ? (
              <div className="space-y-2">
                {standings.map((standing, index) => (
                  <div key={standing.id} className={`flex items-center justify-between p-3 border rounded-lg ${
                    tournament.champion_team_id === standing.team_id ? 'bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/30' : ''
                  }`}>
                    <div className="flex items-center gap-3 flex-1">
                      <div className="font-bold text-lg w-8">#{index + 1}</div>
                      {tournament.champion_team_id === standing.team_id && (
                        <Trophy className="h-5 w-5 text-primary fill-primary" />
                      )}
                      <div className="flex-1">
                        <div className="font-medium flex items-center gap-2">
                          {standing.team?.player1_name} / {standing.team?.player2_name}
                          {tournament.champion_team_id === standing.team_id && (
                            <Badge className="bg-gradient-to-r from-primary to-secondary text-white">Champion</Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 sm:gap-6 text-sm flex-wrap">
                      <div className="text-center">
                        <div className="font-semibold">{standing.wins}-{standing.losses}</div>
                        <div className="text-xs text-muted-foreground">W-L</div>
                      </div>
                      <div className="text-center hidden sm:block">
                        <div className="font-semibold">{standing.points_for}</div>
                        <div className="text-xs text-muted-foreground">PF</div>
                      </div>
                      <div className="text-center hidden sm:block">
                        <div className="font-semibold">{standing.points_against}</div>
                        <div className="text-xs text-muted-foreground">PA</div>
                      </div>
                      <div className="text-center">
                        <div className={`font-semibold ${standing.point_differential >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {standing.point_differential > 0 ? '+' : ''}{standing.point_differential}
                        </div>
                        <div className="text-xs text-muted-foreground">Diff</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                No matches completed yet
              </div>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            No standings available yet. Generate a schedule and complete matches first.
          </CardContent>
        </Card>
      )}
    </TabsContent>

    <TabsContent value="playoffs" className="mt-6">
      {playoffMatches.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-primary" />
              Playoff Bracket
            </CardTitle>
            <CardDescription>Knockout tournament - Top {tournament.playoff_teams} teams</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {(() => {
                const matchesByRound = playoffMatches.reduce((acc, match) => {
                  const round = match.playoff_round || 'Playoffs';
                  if (!acc[round]) acc[round] = [];
                  acc[round].push(match);
                  return acc;
                }, {} as Record<string, TournamentMatch[]>);

                const roundOrder = ['Quarterfinals', 'Semifinals', 'Finals'];
                const sortedRounds = Object.keys(matchesByRound).sort((a, b) => {
                  const idxA = roundOrder.indexOf(a);
                  const idxB = roundOrder.indexOf(b);
                  if (idxA !== -1 && idxB !== -1) return idxA - idxB;
                  if (idxA !== -1) return -1;
                  if (idxB !== -1) return 1;
                  return a.localeCompare(b);
                });

                return sortedRounds.map(round => (
                  <div key={round}>
                    <div className="flex items-center gap-2 mb-4">
                      <div className="h-px bg-gradient-to-r from-primary to-secondary flex-1" />
                      <h3 className="font-bold text-xl px-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                        {round}
                      </h3>
                      <div className="h-px bg-gradient-to-r from-secondary to-primary flex-1" />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {matchesByRound[round].map((match) => (
                        <div
                          key={match.id}
                          className={`p-4 border-2 rounded-xl cursor-pointer hover:shadow-lg transition-all ${
                            match.status === 'completed'
                              ? 'bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/30'
                              : 'border-muted hover:border-primary/30'
                          }`}
                          onClick={() => openScoreDialog(match)}
                        >
                          <div className="space-y-3">
                            <div className="flex items-center justify-between pb-2 border-b">
                              <span className="text-xs font-semibold text-muted-foreground">
                                Match {match.match_number - 1000}
                              </span>
                              {match.status === 'completed' ? (
                                <Badge className="bg-gradient-to-r from-primary to-secondary">Completed</Badge>
                              ) : (
                                <Badge variant="outline">Pending</Badge>
                              )}
                            </div>

                            <div className="p-4 border rounded-lg bg-card">
                              <div className="flex items-center gap-4">
                                <div className="flex-1 space-y-3">
                                  <div className="text-base font-medium text-foreground">
                                    {match.team1?.player1_name} / {match.team1?.player2_name}
                                  </div>
                                  <div className="flex items-center justify-center">
                                    <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                                      <span className="text-white font-bold text-xs">VS</span>
                                    </div>
                                  </div>
                                  <div className="text-base font-medium text-foreground">
                                    {match.team2?.player1_name} / {match.team2?.player2_name}
                                  </div>
                                </div>
                                <div className="flex flex-col gap-3">
                                  {match.status === 'completed' ? (
                                    <>
                                      <div className="w-16 h-10 border-2 border-border rounded flex items-center justify-center bg-background">
                                        <span className="text-xl font-bold">{match.team1_score}</span>
                                      </div>
                                      <div className="w-16 h-10 border-2 border-border rounded flex items-center justify-center bg-background">
                                        <span className="text-xl font-bold">{match.team2_score}</span>
                                      </div>
                                    </>
                                  ) : (
                                    <>
                                      <div className="w-16 h-10 border-2 border-muted rounded flex items-center justify-center bg-muted/30">
                                        <span className="text-lg text-muted-foreground">-</span>
                                      </div>
                                      <div className="w-16 h-10 border-2 border-muted rounded flex items-center justify-center bg-muted/30">
                                        <span className="text-lg text-muted-foreground">-</span>
                                      </div>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>

                            <Button
                              variant={match.status === 'completed' ? 'outline' : 'default'}
                              className="w-full mt-2"
                              size="sm"
                            >
                              {match.status === 'completed' ? 'Edit Score' : 'Enter Score'}
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ));
              })()}
            </div>

            {tournament.champion_team_id && (
              <div className="mt-8 p-6 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 border-2 border-primary/30 rounded-xl text-center">
                <Trophy className="h-12 w-12 mx-auto mb-3 text-primary fill-primary" />
                <h3 className="text-2xl font-black bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-2">
                  Tournament Champion!
                </h3>
                <p className="text-lg font-semibold">
                  {teams.find(t => t.id === tournament.champion_team_id)?.team_name || 'Champion Team'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {teams.find(t => t.id === tournament.champion_team_id)?.player1_name} & {teams.find(t => t.id === tournament.champion_team_id)?.player2_name}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            Playoffs have not started yet
          </CardContent>
        </Card>
      )}
    </TabsContent>
  </Tabs>

      <Dialog open={showScoreDialog} onOpenChange={setShowScoreDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-lg">
              {selectedMatch?.status === 'completed' ? 'Edit Match Score' : 'Enter Match Score'}
            </DialogTitle>
            <DialogDescription className="text-sm">
              Match {selectedMatch?.match_number}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="space-y-4">
              <div className="space-y-3">
                <Label className="text-sm font-semibold">
                  {selectedMatch?.team1?.team_name || `Team ${selectedMatch?.team1?.team_number}`}
                </Label>
                <div className="text-xs text-muted-foreground">
                  {selectedMatch?.team1?.player1_name} & {selectedMatch?.team1?.player2_name}
                </div>
                <Input
                  type="number"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  min="0"
                  value={team1Score}
                  onChange={(e) => setTeam1Score(e.target.value)}
                  placeholder="Score"
                  className="h-14 text-2xl text-center font-bold"
                />
              </div>

              <div className="flex items-center justify-center">
                <div className="text-2xl font-bold text-muted-foreground">VS</div>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-semibold">
                  {selectedMatch?.team2?.team_name || `Team ${selectedMatch?.team2?.team_number}`}
                </Label>
                <div className="text-xs text-muted-foreground">
                  {selectedMatch?.team2?.player1_name} & {selectedMatch?.team2?.player2_name}
                </div>
                <Input
                  type="number"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  min="0"
                  value={team2Score}
                  onChange={(e) => setTeam2Score(e.target.value)}
                  placeholder="Score"
                  className="h-14 text-2xl text-center font-bold"
                />
              </div>
            </div>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setShowScoreDialog(false)} className="w-full sm:w-auto">
              Cancel
            </Button>
            <Button onClick={submitScore} className="w-full sm:w-auto bg-gradient-to-r from-primary to-secondary">
              Submit Score
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showClaimDialog} onOpenChange={setShowClaimDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Claim Team Slot</DialogTitle>
            <DialogDescription>
              Enter your name to claim this spot on Team {selectedTeam?.team_number}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="claim-name">Player Name</Label>
              <Input
                id="claim-name"
                value={claimName}
                onChange={(e) => setClaimName(e.target.value)}
                placeholder="Enter your name"
                autoFocus
              />
            </div>
            {claimError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{claimError}</AlertDescription>
              </Alert>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowClaimDialog(false);
              setClaimName('');
              setClaimError('');
            }}>
              Cancel
            </Button>
            <Button
              onClick={() => confirmClaimTeam(claimName)}
              disabled={!claimName.trim()}
            >
              Claim Slot
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

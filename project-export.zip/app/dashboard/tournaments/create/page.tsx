'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/lib/supabase/client';
import { AlertCircle, Info, Copy, Check } from 'lucide-react';

export default function CreateTournamentPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    date: '',
    startTime: '',
    location: '',
    expectedTeams: 4,
    playoffTeams: 2,
    format: 'round_robin' as 'round_robin' | 'group_stage_playoffs',
    isPrivate: false,
    accessCode: '',
    isDuprRequired: false
  });

  const calculateGames = (teams: number, format: string) => {
    if (format === 'round_robin') {
      return (teams * (teams - 1)) / 2;
    }
    const teamsPerGroup = Math.ceil(teams / 2);
    const groupGames = 2 * ((teamsPerGroup * (teamsPerGroup - 1)) / 2);
    const playoffGames = formData.playoffTeams - 1;
    return groupGames + playoffGames;
  };

  const shouldRecommendGroups = () => {
    const teams = formData.expectedTeams;
    const roundRobinGames = (teams * (teams - 1)) / 2;
    return teams >= 7 && roundRobinGames > 15;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data: tournament, error: insertError } = await supabase
        .from('tournaments')
        .insert({
          name: formData.name,
          created_by: user.id,
          date: formData.date || null,
          start_time: formData.startTime || null,
          location: formData.location || null,
          expected_teams: formData.expectedTeams,
          playoff_teams: formData.playoffTeams,
          format: formData.format,
          best_of: 1,
          is_private: formData.isPrivate,
          access_code: formData.isPrivate ? formData.accessCode : null,
          is_dupr_required: formData.isDuprRequired
        })
        .select()
        .single();

      if (insertError) throw insertError;

      await supabase.from('tournament_participants').insert({
        tournament_id: tournament.id,
        user_id: user.id,
        status: 'approved'
      });

      const teamInserts = Array.from({ length: formData.expectedTeams }, (_, i) => ({
        tournament_id: tournament.id,
        team_number: i + 1,
      }));

      const { error: teamsError } = await supabase
        .from('tournament_teams')
        .insert(teamInserts);

      if (teamsError) throw teamsError;

      router.push(`/dashboard/tournaments/${tournament.id}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const generateAccessCode = () => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    setFormData({ ...formData, accessCode: code });
  };

  const roundRobinGames = calculateGames(formData.expectedTeams, 'round_robin');
  const groupStageGames = calculateGames(formData.expectedTeams, 'group_stage_playoffs');

  return (
    <div className="container max-w-2xl py-8">
      <Card>
        <CardHeader>
          <CardTitle>Create Tournament</CardTitle>
          <CardDescription>Set up a new pickleball tournament</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="name">Tournament Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Summer Pickleball Championship"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="startTime">Start Time</Label>
                <Input
                  id="startTime"
                  type="time"
                  value={formData.startTime}
                  onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="Community Sports Center"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="expectedTeams">Expected Teams *</Label>
                <Select
                  value={formData.expectedTeams.toString()}
                  onValueChange={(value) => setFormData({ ...formData, expectedTeams: parseInt(value) })}
                >
                  <SelectTrigger id="expectedTeams">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 11 }, (_, i) => i + 2).map((num) => (
                      <SelectItem key={num} value={num.toString()}>
                        {num} Teams
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="playoffTeams">Playoff Teams *</Label>
                <Select
                  value={formData.playoffTeams.toString()}
                  onValueChange={(value) => setFormData({ ...formData, playoffTeams: parseInt(value) })}
                >
                  <SelectTrigger id="playoffTeams">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[2, 3, 4, 5, 6].map((num) => (
                      <SelectItem key={num} value={num.toString()}>
                        {num} Teams
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {shouldRecommendGroups() && (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  With {formData.expectedTeams} teams, recommend using Groups! Full round robin = {roundRobinGames} games,
                  2 groups = {groupStageGames} group games+playoffs.
                </AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="format">Tournament Format *</Label>
              <Select
                value={formData.format}
                onValueChange={(value: 'round_robin' | 'group_stage_playoffs') =>
                  setFormData({ ...formData, format: value })
                }
              >
                <SelectTrigger id="format">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="round_robin">Round Robin</SelectItem>
                  <SelectItem value="group_stage_playoffs">Group Stage + Playoffs</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="isDuprRequired">DUPR Required</Label>
                  <p className="text-sm text-muted-foreground">
                    Only users with DUPR accounts can join
                  </p>
                </div>
                <Switch
                  id="isDuprRequired"
                  checked={formData.isDuprRequired}
                  onCheckedChange={(checked) => setFormData({ ...formData, isDuprRequired: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="isPrivate">Private Tournament</Label>
                  <p className="text-sm text-muted-foreground">
                    Require approval or access code to join
                  </p>
                </div>
                <Switch
                  id="isPrivate"
                  checked={formData.isPrivate}
                  onCheckedChange={(checked) => setFormData({ ...formData, isPrivate: checked })}
                />
              </div>

              {formData.isPrivate && (
                <div className="space-y-2 pl-4 border-l-2">
                  <Label htmlFor="accessCode">Access Code (Optional)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="accessCode"
                      value={formData.accessCode}
                      onChange={(e) => setFormData({ ...formData, accessCode: e.target.value })}
                      placeholder="Enter or generate code"
                    />
                    <Button type="button" variant="outline" onClick={generateAccessCode}>
                      Generate
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Users can join with this code or request access
                  </p>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              <Button type="submit" disabled={loading} className="flex-1">
                {loading ? 'Creating...' : 'Create Tournament'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => router.back()}
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

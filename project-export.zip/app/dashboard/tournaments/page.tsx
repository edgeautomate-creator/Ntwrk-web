'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, MapPin, Users, Trophy, Plus, Lock, Search } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

interface Tournament {
  id: string;
  name: string;
  date: string | null;
  start_time: string | null;
  location: string | null;
  expected_teams: number;
  playoff_teams: number;
  format: string;
  best_of: number;
  is_private: boolean;
  access_code: string | null;
  created_by: string;
  created_at: string;
  updated_at: string;
  participant_count?: number;
}

export default function TournamentsPage() {
  const router = useRouter();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'my-tournaments'>('all');
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState('');

  useEffect(() => {
    loadTournaments();
  }, [activeTab]);

  const loadTournaments = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      let query = supabase
        .from('tournaments')
        .select('*')
        .order('updated_at', { ascending: false });

      if (activeTab === 'my-tournaments') {
        const { data: myParticipations } = await supabase
          .from('tournament_participants')
          .select('tournament_id')
          .eq('user_id', user.id)
          .eq('status', 'approved');

        const participantTournamentIds = myParticipations?.map(p => p.tournament_id) || [];

        if (participantTournamentIds.length > 0) {
          query = query.or(`created_by.eq.${user.id},id.in.(${participantTournamentIds.join(',')})`);
        } else {
          query = query.eq('created_by', user.id);
        }
      }

      const { data: tournamentsData, error } = await query;

      if (error) throw error;

      const tournamentsWithCounts = await Promise.all(
        (tournamentsData || []).map(async (tournament) => {
          const { data: teams } = await supabase
            .from('tournament_teams')
            .select('player1_name, player2_name')
            .eq('tournament_id', tournament.id);

          const filledTeamsCount = teams?.filter(t => t.player1_name && t.player2_name).length || 0;

          return {
            ...tournament,
            participant_count: filledTeamsCount
          };
        })
      );

      setTournaments(tournamentsWithCounts);
    } catch (error) {
      console.error('Error loading tournaments:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredTournaments = tournaments.filter(tournament =>
    tournament.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tournament.location?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return null;
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatTime = (timeStr: string | null) => {
    if (!timeStr) return null;
    return new Date(`2000-01-01T${timeStr}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const handleTournamentClick = async (tournament: Tournament) => {
    if (tournament.is_private) {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      if (tournament.created_by === user.id) {
        router.push(`/dashboard/tournaments/${tournament.id}`);
        return;
      }

      const { data: participation } = await supabase
        .from('tournament_participants')
        .select('id')
        .eq('tournament_id', tournament.id)
        .eq('user_id', user.id)
        .eq('status', 'approved')
        .maybeSingle();

      if (participation) {
        router.push(`/dashboard/tournaments/${tournament.id}`);
        return;
      }

      setSelectedTournament(tournament);
      setShowPasswordDialog(true);
      setPasswordInput('');
      setPasswordError('');
    } else {
      router.push(`/dashboard/tournaments/${tournament.id}`);
    }
  };

  const verifyPasswordAndEnter = async () => {
    if (!selectedTournament) return;

    if (passwordInput !== selectedTournament.access_code) {
      setPasswordError('Incorrect password. Please try again.');
      return;
    }

    setShowPasswordDialog(false);
    setPasswordInput('');
    setPasswordError('');
    router.push(`/dashboard/tournaments/${selectedTournament.id}`);
  };

  return (
    <div className="container py-6 max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">Tournaments</h1>
          <p className="text-white/70">Browse and join pickleball tournaments</p>
        </div>
        <Button
          onClick={() => router.push('/dashboard/tournaments/create')}
          className="dinkheads-button-primary h-12 px-6 text-base"
        >
          <Plus className="h-5 w-5 mr-2" />
          Create Tournament
        </Button>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-4 top-4 h-5 w-5 text-white/50" />
          <Input
            placeholder="Search tournaments..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 h-14 text-base dinkheads-input"
          />
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="mb-6">
        <TabsList className="bg-white/10 border-2 border-white/20 h-12">
          <TabsTrigger
            value="all"
            className="data-[state=active]:bg-gradient-to-b data-[state=active]:from-gray-200 data-[state=active]:to-gray-300 data-[state=active]:text-gray-800 text-white rounded-xl"
          >
            All Tournaments
          </TabsTrigger>
          <TabsTrigger
            value="my-tournaments"
            className="data-[state=active]:bg-gradient-to-b data-[state=active]:from-gray-200 data-[state=active]:to-gray-300 data-[state=active]:text-gray-800 text-white rounded-xl"
          >
            My Tournaments
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {loading ? (
        <div className="grid gap-6 md:grid-cols-1">
          {[1, 2, 3].map((i) => (
            <div key={i} className="dinkheads-card animate-pulse p-6">
              <div className="h-6 bg-white/20 rounded w-3/4 mb-2" />
              <div className="h-4 bg-white/20 rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : filteredTournaments.length === 0 ? (
        <div className="dinkheads-card p-12">
          <div className="flex flex-col items-center justify-center text-center">
            <Trophy className="h-16 w-16 text-[#4a5f73] mb-6" />
            <h3 className="text-2xl font-bold text-white mb-3">No tournaments found</h3>
            <p className="text-white/70 mb-6 max-w-md">
              {searchQuery
                ? 'Try adjusting your search'
                : 'Be the first to create a tournament!'}
            </p>
            {!searchQuery && (
              <Button
                onClick={() => router.push('/dashboard/tournaments/create')}
                className="dinkheads-button-primary h-12 px-8 text-base"
              >
                <Plus className="h-5 w-5 mr-2" />
                Create Tournament
              </Button>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredTournaments.map((tournament) => (
            <div
              key={tournament.id}
              className="dinkheads-card p-6 hover:shadow-[0_12px_48px_rgba(0,0,0,0.4)] transition-all cursor-pointer"
              onClick={() => handleTournamentClick(tournament)}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-xl font-bold text-white">{tournament.name}</h3>
                        {tournament.is_private && (
                          <Lock className="h-4 w-4 text-white/50 flex-shrink-0" />
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge className="bg-white/20 text-white border-0 rounded-full">
                          {tournament.format === 'round_robin' ? 'Round Robin' : 'Group Stage'}
                        </Badge>
                        <Badge className="bg-[#5dd9a8]/20 text-[#5dd9a8] border-0 rounded-full">
                          Best of {tournament.best_of}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-white/80">
                    {tournament.date && (
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-white/50" />
                        <span>
                          {formatDate(tournament.date)}
                          {tournament.start_time && ` at ${formatTime(tournament.start_time)}`}
                        </span>
                      </div>
                    )}
                    {tournament.location && (
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-white/50" />
                        <span>{tournament.location}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-white/50" />
                      <span>
                        {tournament.participant_count || 0} / {tournament.expected_teams} teams
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-xs text-white/50 sm:text-right">
                  Updated {formatDistanceToNow(new Date(tournament.updated_at), { addSuffix: true })}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent className="dinkheads-card border-white/20">
          <DialogHeader>
            <DialogTitle className="text-white text-xl">Tournament Password Required</DialogTitle>
            <DialogDescription className="text-white/70">
              This is a private tournament. Enter the password to continue.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="password" className="text-white">Password</Label>
              <Input
                id="password"
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Enter tournament password"
                className="dinkheads-input"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && passwordInput.trim()) {
                    verifyPasswordAndEnter();
                  }
                }}
              />
            </div>
            {passwordError && (
              <Alert variant="destructive" className="bg-red-500/20 border-red-500/50 text-white">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{passwordError}</AlertDescription>
              </Alert>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowPasswordDialog(false);
                setPasswordInput('');
                setPasswordError('');
              }}
              className="dinkheads-button-secondary"
            >
              Cancel
            </Button>
            <Button
              onClick={verifyPasswordAndEnter}
              disabled={!passwordInput.trim()}
              className="dinkheads-button-primary"
            >
              Enter Tournament
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

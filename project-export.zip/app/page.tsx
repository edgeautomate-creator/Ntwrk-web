'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/contexts/auth-context';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';
import { Trophy, Users, TrendingUp } from 'lucide-react';

export default function Home() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && user) {
      router.push('/dashboard');
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#3d4f5f]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#5dd9a8] border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#374555] to-[#3d4f5f] flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-4xl">
        <div className="text-center space-y-8 mb-12">
          <div className="flex justify-center">
            <Image
              src="/dinkheads_logo_final.png"
              alt="DinkHeads"
              width={400}
              height={400}
              className="w-64 md:w-96 h-auto drop-shadow-[0_8px_16px_rgba(0,0,0,0.4)]"
              priority
            />
          </div>

          <div className="space-y-4">
            <h2 className="text-2xl md:text-3xl font-bold text-white">
              Pickleball Tournament Management
            </h2>
            <p className="text-base md:text-lg text-gray-300 max-w-2xl mx-auto">
              Manage tournaments, track rankings, and connect with the pickleball community.
            </p>
          </div>

          <div className="flex flex-col gap-4 max-w-2xl mx-auto pt-4">
            <Link href="/signup" className="w-full">
              <Button
                size="lg"
                className="w-full h-16 text-xl font-bold bg-gradient-to-r from-[#5dd9a8] to-[#4bc997] hover:from-[#4bc997] hover:to-[#3ab886] text-white rounded-3xl shadow-[0_8px_16px_rgba(0,0,0,0.3)] transition-all hover:shadow-[0_12px_24px_rgba(0,0,0,0.4)] border-b-4 border-[#3ab886]"
              >
                Get Started Free
              </Button>
            </Link>
            <Link href="/login" className="w-full">
              <Button
                size="lg"
                variant="outline"
                className="w-full h-16 text-xl font-bold bg-gradient-to-b from-gray-200 to-gray-300 hover:from-gray-300 hover:to-gray-400 text-gray-800 rounded-3xl shadow-[0_8px_16px_rgba(0,0,0,0.3)] transition-all hover:shadow-[0_12px_24px_rgba(0,0,0,0.4)] border-t-4 border-white/50 border-b-4 border-gray-400"
              >
                Sign In
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 md:gap-6 pt-8">
          <div className="bg-gradient-to-b from-gray-100 to-gray-200 rounded-2xl md:rounded-3xl p-3 md:p-8 shadow-[0_8px_16px_rgba(0,0,0,0.3)] border-t-4 border-white/50">
            <div className="flex justify-center mb-2 md:mb-6">
              <Trophy className="h-8 w-8 md:h-16 md:w-16 text-[#5dd9a8]" strokeWidth={2.5} />
            </div>
            <h3 className="text-xs md:text-2xl font-bold mb-1 md:mb-3 text-gray-800 text-center">Tournament Ready</h3>
            <p className="text-[10px] md:text-base text-gray-600 text-center leading-relaxed">
              Create and manage tournaments with ease. DUPR integration included.
            </p>
          </div>

          <div className="bg-gradient-to-b from-gray-100 to-gray-200 rounded-2xl md:rounded-3xl p-3 md:p-8 shadow-[0_8px_16px_rgba(0,0,0,0.3)] border-t-4 border-white/50">
            <div className="flex justify-center mb-2 md:mb-6">
              <Users className="h-8 w-8 md:h-16 md:w-16 text-[#a78ed9]" strokeWidth={2.5} />
            </div>
            <h3 className="text-xs md:text-2xl font-bold mb-1 md:mb-3 text-gray-800 text-center">Team Management</h3>
            <p className="text-[10px] md:text-base text-gray-600 text-center leading-relaxed">
              Organize teams, track players, and manage registrations seamlessly.
            </p>
          </div>

          <div className="bg-gradient-to-b from-gray-100 to-gray-200 rounded-2xl md:rounded-3xl p-3 md:p-8 shadow-[0_8px_16px_rgba(0,0,0,0.3)] border-t-4 border-white/50">
            <div className="flex justify-center mb-2 md:mb-6">
              <TrendingUp className="h-8 w-8 md:h-16 md:w-16 text-[#f4b942]" strokeWidth={2.5} />
            </div>
            <h3 className="text-xs md:text-2xl font-bold mb-1 md:mb-3 text-gray-800 text-center">Live Rankings</h3>
            <p className="text-[10px] md:text-base text-gray-600 text-center leading-relaxed">
              Real-time standings and statistics to keep everyone engaged.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

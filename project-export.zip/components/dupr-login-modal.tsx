'use client';

import { useEffect, useState, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase/client';
import { ExternalLink, Loader2 } from 'lucide-react';

interface DUPRLoginModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

interface DUPRLoginMessage {
  userToken: string;
  refreshToken: string;
  id: string;
  duprId: string;
  email?: string;
  fullName?: string;
  stats?: {
    singles?: number;
    doubles?: number;
  };
}

export function DUPRLoginModal({ open, onOpenChange, onSuccess }: DUPRLoginModalProps) {
  const [loading, setLoading] = useState(false);
  const [waitingForAuth, setWaitingForAuth] = useState(false);
  const popupRef = useRef<Window | null>(null);
  const pollIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const clientIdBase64 = typeof window !== 'undefined'
    ? (process.env.NEXT_PUBLIC_DUPR_CLIENT_ID_BASE64 || 'dGVzdC1jay0wYTlkMzkzNS0xYTAwLTQ2YmUtZmJmOS02Mzc2ZDRhZjYzN2M=')
    : 'dGVzdC1jay0wYTlkMzkzNS0xYTAwLTQ2YmUtZmJmOS02Mzc2ZDRhZjYzN2M=';
  const duprLoginUrl = `https://uat.dupr.gg/login-external-app/${clientIdBase64}`;

  const checkProfileUpdate = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return false;

      const { data: profile } = await supabase
        .from('profiles')
        .select('dupr_id, dupr_user_token')
        .eq('id', user.id)
        .maybeSingle();

      return profile && profile.dupr_user_token;
    } catch (error) {
      console.error('Error checking profile:', error);
      return false;
    }
  };

  const startPolling = () => {
    pollIntervalRef.current = setInterval(async () => {
      const isUpdated = await checkProfileUpdate();
      if (isUpdated) {
        if (pollIntervalRef.current) {
          clearInterval(pollIntervalRef.current);
          pollIntervalRef.current = null;
        }
        if (popupRef.current && !popupRef.current.closed) {
          popupRef.current.close();
        }
        setWaitingForAuth(false);
        setLoading(false);
        onOpenChange(false);
        if (onSuccess) onSuccess();
      }
    }, 2000);
  };

  useEffect(() => {
    const handleMessage = async (event: MessageEvent) => {
      console.log('Received message from:', event.origin);
      console.log('Message data:', event.data);

      if (event.origin !== 'https://uat.dupr.gg') return;

      const data = event.data as DUPRLoginMessage;

      if (data.userToken && data.duprId) {
        setWaitingForAuth(false);
        setLoading(true);

        if (popupRef.current && !popupRef.current.closed) {
          popupRef.current.close();
        }

        try {
          const { data: { user } } = await supabase.auth.getUser();
          if (!user) return;

          const { error } = await supabase
            .from('profiles')
            .update({
              dupr_id: data.duprId,
              full_name: data.fullName || data.email || 'DUPR User',
              dupr_singles_rating: data.stats?.singles || null,
              dupr_doubles_rating: data.stats?.doubles || null,
              dupr_user_token: data.userToken,
              dupr_refresh_token: data.refreshToken,
              updated_at: new Date().toISOString(),
            })
            .eq('id', user.id);

          if (error) throw error;

          onOpenChange(false);
          if (onSuccess) onSuccess();
        } catch (error) {
          console.error('Error saving DUPR data:', error);
          alert('Failed to link DUPR account. Please try again.');
        } finally {
          setLoading(false);
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
      if (popupRef.current && !popupRef.current.closed) {
        popupRef.current.close();
      }
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
        pollIntervalRef.current = null;
      }
    };
  }, [onOpenChange, onSuccess]);

  const handleOpenDUPRLogin = () => {
    const width = 500;
    const height = 700;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;

    popupRef.current = window.open(
      duprLoginUrl,
      'DUPR Login',
      `width=${width},height=${height},left=${left},top=${top},toolbar=no,location=no,menubar=no`
    );

    setWaitingForAuth(true);
    startPolling();

    const checkPopup = setInterval(() => {
      if (popupRef.current && popupRef.current.closed) {
        clearInterval(checkPopup);
        if (pollIntervalRef.current) {
          clearInterval(pollIntervalRef.current);
          pollIntervalRef.current = null;
        }
        setWaitingForAuth(false);
      }
    }, 500);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Connect with DUPR</DialogTitle>
          <DialogDescription>
            A popup window will open for you to sign in with your DUPR account.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {loading ? (
            <div className="text-center py-8">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
              <p className="text-sm text-muted-foreground">Linking your DUPR account...</p>
            </div>
          ) : waitingForAuth ? (
            <div className="text-center py-8">
              <div className="animate-pulse mb-4">
                <ExternalLink className="h-8 w-8 mx-auto" />
              </div>
              <p className="text-sm text-muted-foreground mb-2">
                Waiting for you to complete login in the popup window...
              </p>
              <p className="text-xs text-muted-foreground">
                If the popup was blocked, please allow popups and try again.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Click the button below to open a secure DUPR login window. After signing in, your account will be automatically linked.
              </p>
              <Button
                onClick={handleOpenDUPRLogin}
                className="w-full"
                size="lg"
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Open DUPR Login
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
